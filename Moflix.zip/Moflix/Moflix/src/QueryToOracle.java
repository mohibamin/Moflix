/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohib
 */


public class QueryToOracle {
    OConnect OC = new OConnect();
    public QueryToOracle(){
        
    }
    
     public void findQuery(int n){
        switch (n){
            case 1: {
                OC.printQuery("SELECT * FROM EXISTING_USER");
                break;
            }
            case 2: {
                OC.printQuery("SELECT * FROM NEW_USER");
                break;
            }
            case 3: {
                OC.printQuery("SELECT * FROM \"SUBSCRIPTION\"");
                break;
            }
            case 4: {
                OC.printQuery("SELECT * FROM \"ACCOUNT\"");
                break;
            }
            case 5: {
                OC.printQuery("SELECT * FROM \"ACTORS\"");
                break;
            }
            case 6: {
                OC.printQuery("SELECT * FROM \"DIRECTORS\"");
                break;
            }
            case 7: {
                OC.printQuery("SELECT * FROM \"TVSHOWS\"");
                break;
            }
            case 8: {
                OC.printQuery("SELECT * FROM \"MOVIES\"");
                break;
            }
            default: {
                break;
            }
                
            
        }
    }
    
    
                
    public Object[] sendStringCT(){
        String[] createTableStatements = {
        " CREATE TABLE EXISTING_USER\n" +
"(\n" +
"	\"e_userID\" SMALLINT PRIMARY KEY,\n" +
"	\"e_username\" VARCHAR(20) NOT NULL UNIQUE,\n" +
"	\"e_password\" VARCHAR(20) NOT NULL,\n" +
"	\"confirm_pass\" VARCHAR(20),\n" +
"	\"email\" VARCHAR(30) UNIQUE,\n" +
"	\"firstname\" VARCHAR(20),\n" +
"	\"lastname\" VARCHAR(20),\n" +
"	\"phoneNumber\" VARCHAR2(20) DEFAULT '-1' UNIQUE\n" +
")", //done
        "  CREATE TABLE NEW_USER\n" +
"(\n" +
"	\"userID\" SMALLINT PRIMARY KEY,\n" +
"	\"e_userID\" SMALLINT REFERENCES EXISTING_USER (\"e_userID\"),\n" +
"	\"username\" VARCHAR(20) UNIQUE,\n" +
"	\"password\" VARCHAR(20),\n" +
"	\"confirm_pass\" VARCHAR(20),\n" +
"	\"email\" VARCHAR(30) UNIQUE,\n" +
"	\"firstname\" VARCHAR(20),\n" +
"	\"lastname\" VARCHAR(20),\n" +
"	\"phoneNumber\" VARCHAR2(20) DEFAULT '-1' UNIQUE\n" +
")", //done
        "  CREATE TABLE \"USER_ADDRESS\" (\n" +
"    \"e_userID\" SMALLINT PRIMARY KEY,\n" +
"    \"user_address\" VARCHAR(255),\n" +
"    FOREIGN KEY (\"e_userID\") REFERENCES \"EXISTING_USER\" (\"e_userID\")\n" +
") ", //done
        " CREATE TABLE \"SUBSCRIPTION\" (\n" +
"    \"plan\" VARCHAR(20) PRIMARY KEY,\n" +
"    \"e_userID\" SMALLINT REFERENCES \"EXISTING_USER\" (\"e_userID\"),\n" +
"    \"payment_method\" VARCHAR(20),\n" +
"    \"card_num\" VARCHAR(20),\n" +
"    \"card_expiry\" VARCHAR(20),\n" +
"    \"card_security_code\" VARCHAR(6),\n" +
"    FOREIGN KEY (\"e_userID\") REFERENCES \"USER_ADDRESS\" (\"e_userID\")\n" +
"    \"address\" VARCHAR(30),\n" +
"    \"billing_address\" VARCHAR(30)\n" +
")", //done
        " CREATE TABLE \"PLAN_COST\"\n" +
"(\n" +
"    \"plan\" VARCHAR(20) PRIMARY KEY,\n" +
"    \"subscription_cost\" DECIMAL(10, 2)\n" +
")", //done
        "  CREATE TABLE ACCOUNT\n" +
"(\n" +
"	\"accountID\" SMALLINT PRIMARY KEY,\n" +
"	\"plan\" VARCHAR(20) REFERENCES SUBSCRIPTION (\"plan\"),\n" +
"	\"e_userID\" SMALLINT REFERENCES EXISTING_USER (\"e_userID\")\n" +
")", //done
        "  CREATE TABLE ACCOUNT_PLAN\n" +
"(\n" +
"	\"accountID\" SMALLINT PRIMARY KEY,\n" +
"	\"plan\" VARCHAR(20) REFERENCES SUBSCRIPTION (\"plan\")\n" +
")", //done
        "  CREATE TABLE ACCOUNT_USER\n" +
"(\n" +
"	\"accountID\" SMALLINT PRIMARY KEY,\n" +
"	\"e_userID\" SMALLINT REFERENCES EXISTING_USER (\"e_userID\")\n" +
")", //done
        "  CREATE TABLE ACTORS\n" +
"(\n" +
"	\"actorID\" SMALLINT PRIMARY KEY,\n" +
"	\"name_actor\" VARCHAR(20),\n" +
"	\"dob_actor\" VARCHAR(20),\n" +
"	\"nationality_actor\" VARCHAR(20)\n" +
")", //done 
        "  CREATE TABLE DIRECTORS\n" +
"(\n" +
"	\"directorID\" SMALLINT PRIMARY KEY,\n" +
"	\"name_director\" VARCHAR(20),\n" +
"	\"dob_director\" VARCHAR(20),\n" +
"	\"nationality_director\" VARCHAR(20)\n" +
")", //done 
        "  CREATE TABLE \"TVSHOWS\"\n" +
"(\n" +
"	\"tvID\" SMALLINT PRIMARY KEY,\n" +
"    \"tvshow_name\" VARCHAR(20),\n" +
"	\"genre\" VARCHAR(20),                                             \n" +
"	\"actor\" SMALLINT REFERENCES \"ACTORS\" (\"actorID\"),\n" +
"	\"rating\" SMALLINT,\n" +
"	\"duration\" VARCHAR(20),                                          \n" +
"	\"director\" SMALLINT REFERENCES \"DIRECTORS\" (\"directorID\")\n" +
")", // done
        "CREATE TABLE \"MOVIES\"\n" +
"(\n" +
"	\"movieID\" SMALLINT PRIMARY KEY,\n" +
"    \"movie_name\" VARCHAR(20),\n" +
"    \"genre\" VARCHAR(20),                                            \n" +
"	\"actor\" SMALLINT REFERENCES \"ACTORS\" (\"actorID\"),\n" +
"	\"rating\" SMALLINT,\n" +
"	\"duration\" VARCHAR(20),                                         \n" +
"	\"director\" SMALLINT REFERENCES \"DIRECTORS\" (\"directorID\")\n" +
")", // done
        "CREATE TABLE \"TVSHOW_GENRE\"\n" +
"(\n" +
"    \"tvID\" SMALLINT,\n" +
"    \"genre\" VARCHAR(20),\n" +
"    PRIMARY KEY (\"tvID\", \"genre\"),\n" +
"    FOREIGN KEY (\"tvID\") REFERENCES \"TVSHOWS\"(\"tvID\")\n" +
")", //done
        "CREATE TABLE \"TVSHOW_DURATION\"\n" +
"(\n" +
"    \"tvID\" SMALLINT,\n" +
"    \"duration\" VARCHAR(20),\n" +
"    PRIMARY KEY (\"tvID\", \"duration\"),\n" +
"    FOREIGN KEY (\"tvID\") REFERENCES \"TVSHOWS\"(\"tvID\")\n" +
")", //done
        "CREATE TABLE \"MOVIE_GENRE\"\n" +
"(\n" +
"    \"movieID\" SMALLINT,\n" +
"    \"genre\" VARCHAR(20),\n" +
"    PRIMARY KEY (\"movieID\", \"genre\"),\n" +
"    FOREIGN KEY (\"movieID\") REFERENCES \"MOVIES\"(\"movieID\")\n" +
")", //done
        "CREATE TABLE \"MOVIE_DURATION\"\n" +
"(\n" +
"    \"movieID\" SMALLINT,\n" +
"    \"duration\" VARCHAR(20),\n" +
"    PRIMARY KEY (\"movieID\", \"duration\"),\n" +
"    FOREIGN KEY (\"movieID\") REFERENCES \"MOVIES\"(\"movieID\")\n" +
")",
        "CREATE TABLE RECENTLY_WATCHED\n" +
"(\n" +
"	\"e_userID\" SMALLINT REFERENCES EXISTING_USER (\"e_userID\"),\n" +
"	\"movieID\" SMALLINT REFERENCES MOVIES (\"movieID\"),\n" +
"	\"tvID\" SMALLINT REFERENCES TVSHOWS (\"tvID\")\n" +
")"};
        
        return OC.createTables(createTableStatements);
    }
    public Object[] sendStringDT(){
        return OC.dropTables();
        
    }
    
    public Object[] sendStringPT(){
        String[] populateTableStatements = {
    "INSERT INTO \"EXISTING_USER\"(\"e_userID\", \"e_username\", \"e_password\")\n" +
    "VALUES(2001, 'adam123', 'password123')\n" +
    "\n" +
    "INSERT INTO \"EXISTING_USER\"(\"e_userID\", \"e_username\", \"e_password\")\n" +
    "VALUES(2002, 'ronaldo7', 'messi10') \n" +
    "\n" +
    "INSERT INTO \"EXISTING_USER\"(\"e_userID\", \"e_username\", \"e_password\")\n" +
    "VALUES(2003, 'lebron23', 'mjordan23')",
    
    "INSERT INTO \"NEW_USER\"(\"userID\", \"e_userID\",\"username\", \"password\",\"confirm_pass\",\"email\",\"firstname\",\"lastname\",\"phoneNumber\")\n" +
    "VALUES(1003, NULL, 'drake6', 'weekend123', 'weekend123','drakeddr@gmail.com','Aubrey', 'Graham', '647-234-2345')\n" +
    "\n" +
    "INSERT INTO \"NEW_USER\"(\"userID\", \"e_userID\", \"username\", \"password\",\"confirm_pass\",\"email\",\"firstname\",\"lastname\",\"phoneNumber\")\n" +
    "VALUES(1004, NULL,'brazil777', 'argentina10', 'argentina10', 'brazil2020@yahoo.ca', 'Brasillia', 'Alcapone', '416-345-765')\n" +
    "\n" +
    "INSERT INTO \"NEW_USER\"(\"userID\", \"e_userID\", \"username\", \"password\",\"confirm_pass\",\"email\",\"firstname\",\"lastname\",\"phoneNumber\")\n" +
    "VALUES(1005, NULL, 'golazo23',  'vamos456', 'vamos456', 'ggolzo@hotmail.com', 'Gonzalez', 'Perrero', '437-987-543')",
    
    "INSERT INTO \"SUBSCRIPTION\"(\"plan\", \"e_userID\", \"payment_method\", \"card_num\",\"card_expiry\",\"card_security_code\",\"address\", \"billing_address\")\n" +
    "VALUES('standard', 2001, 'credit', '1234-4578-9876-1238', '02/26', '345', '345 apple street', '345 apple street')\n" +
    "\n" +
    "INSERT INTO \"SUBSCRIPTION\"(\"plan\", \"e_userID\", \"payment_method\", \"card_num\",\"card_expiry\",\"card_security_code\",\"address\", \"billing_address\")\n" +
    "VALUES('premium', 2002, 'paypal', '6554-9576-1234-8362', '04/28','237', '876 pear street', '876 pear street')\n" +
    "\n" +
    "INSERT INTO \"SUBSCRIPTION\"(\"plan\", \"e_userID\", \"payment_method\", \"card_num\",\"card_expiry\",\"card_security_code\",\"address\", \"billing_address\")\n" +
    "VALUES('student', 2003, 'e-transfer',  '8362-3749-1432-8352', '07/25','912', '433 orange street', '433 orange street')",
    
    "INSERT INTO \"ACCOUNT\"(\"accountID\", \"plan\", \"e_userID\")\n" +
    "VALUES(561, 'standard', 2001) \n" +
    "\n" +
    "INSERT INTO \"ACCOUNT\"(\"accountID\", \"plan\", \"e_userID\")\n" +
    "VALUES(562, 'premium', 2002)\n" +
    "\n" +
    "INSERT INTO \"ACCOUNT\"(\"accountID\", \"plan\", \"e_userID\")\n" +
    "VALUES(563, 'student', 2003)",
    
    "INSERT INTO \"ACCOUNT\"(\"accountID\", \"plan\", \"e_userID\")\n" +
    "VALUES(561, 'standard', 2001) \n" +
    "\n" +
    "INSERT INTO \"ACCOUNT\"(\"accountID\", \"plan\", \"e_userID\")\n" +
    "VALUES(562, 'premium', 2002)\n" +
    "\n" +
    "INSERT INTO \"ACCOUNT\"(\"accountID\", \"plan\", \"e_userID\")\n" +
    "VALUES(563, 'student', 2003)",
    
    "INSERT INTO \"ACTORS\"(\"actorID\", \"name_actor\", \"dob_actor\", \"nationality_actor\")\n" +
    "VALUES(3, 'Bryan Cranston','March 7, 1956', 'American')\n" +
    "\n" +
    "INSERT INTO \"ACTORS\"(\"actorID\", \"name_actor\", \"dob_actor\", \"nationality_actor\")\n" +
    "VALUES(4, 'Cillian Murphy','May 25, 1976', 'British')\n" +
    "\n" +
    "INSERT INTO \"ACTORS\"(\"actorID\", \"name_actor\", \"dob_actor\", \"nationality_actor\")\n" +
    "VALUES(5, 'Jonah Hill' ,'December 20, 1983', 'American')\n" +
    "\n" +
    "INSERT INTO \"ACTORS\"(\"actorID\", \"name_actor\", \"dob_actor\", \"nationality_actor\")\n" +
    "VALUES(6, 'Christian Bale' , 'January 30, 1974', 'America')",
    
    "INSERT INTO \"DIRECTORS\" (\"directorID\", \"name_director\", \"dob_director\", \"nationality_director\")\n" +
    "VALUES(8, 'Vince Gilligan', 'February 10, 1967', 'American')\n" +
    "\n" +
    "INSERT INTO \"DIRECTORS\" (\"directorID\", \"name_director\", \"dob_director\", \"nationality_director\")\n" +
    "VALUES(9, 'Otto Bathurst', 'June 16, 1971', 'British')\n" +
    "\n" +
    "INSERT INTO \"DIRECTORS\" (\"directorID\", \"name_director\", \"dob_director\", \"nationality_director\")\n" +
    "VALUES(10, 'Chris Miller', 'September 23, 1975', 'American')\n" +
    "\n" +
    "INSERT INTO \"DIRECTORS\" (\"directorID\", \"name_director\", \"dob_director\", \"nationality_director\")\n" +
    "VALUES(11, 'Christopher Nolan', 'July 30, 1970', 'British')",
    
    "INSERT INTO \"TVSHOWS\"(\"tvID\", \"tvshow_name\", \"genre\", \"actor\", \"rating\", \"duration\", \"director\")\n" +
    "VALUES(10, 'breaking bad', 'drama', 3, 95, '5 seasons', 8)\n" +
    "\n" +
    "INSERT INTO \"TVSHOWS\"(\"tvID\", \"tvshow_name\", \"genre\", \"actor\", \"rating\", \"duration\", \"director\")\n" +
    "VALUES(11, 'peaky blinders', 'crime', 4, 88, '6 seasons', 9)",
    
    "INSERT INTO \"MOVIES\"(\"movieID\",\"movie_name\", \"genre\", \"actor\", \"rating\", \"duration\", \"director\")\n" +
    "VALUES(12, '21 Jump Street', 'comedy', 5, 72, '1h 49m', 10)\n" +
    "\n" +
    "INSERT INTO \"MOVIES\"(\"movieID\",\"movie_name\", \"genre\", \"actor\", \"rating\", \"duration\", \"director\")\n" +
    "VALUES(13, 'The Dark Knight', 'adventure', 6, 90 , '2h 32m', 11)",
        
        };
    
        
       return OC.populateTables(populateTableStatements);
    }
    
    
}
    
    
    
    

