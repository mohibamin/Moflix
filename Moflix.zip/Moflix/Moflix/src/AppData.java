 import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public class AppData {
    private static AppData instance;
    private List<String[]> recentlyWatched;

    private AppData() {
        recentlyWatched = new ArrayList<>();
    }

    public static AppData getInstance() {
        if (instance == null) {
            instance = new AppData();
        }
        return instance;
    }

    public List<String[]> getRecentlyWatched() {
        return recentlyWatched;
    }

    public void addToRecentlyWatched(String[] movie) {
        // Remove if the movie is already in the list
        recentlyWatched.removeIf(existingMovie -> Arrays.equals(existingMovie, movie));

        // Add to the start of the list
        recentlyWatched.add(0, movie);

    }
}
