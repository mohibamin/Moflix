Hello to whoever is viewing this file!

To start, you will need to open up the program either on netbeans 8.2, or netbeans 19. The code will not run until you copy and paste the SQL database from the other txt file to the TMU Host Database.
Unfortunately the user cannot use my login to connect to the TMU Host Database, so instead you will need to change the code on OConnect.Java, LoginDBMS, and RegisterDBMS to there own account.
Other than that, everything will work perfect.

Thanks again and I hope you enjoy!